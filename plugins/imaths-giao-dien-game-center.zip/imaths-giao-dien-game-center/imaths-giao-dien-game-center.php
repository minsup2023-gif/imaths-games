<?php
/**
 * Plugin Name: iMaths Games – Giao diện Game Center
 * Description: Khoác giao diện kiểu Game Center cho sân chơi iMaths Games: thanh lọc (Tất cả · Chơi tiếp · Game mới · Hot · theo chủ đề), banner trượt game nổi bật, lưới ô game vuông có nhãn "Mới/Hot", thanh điều hướng dưới cùng như app. Không sửa plugin chính – tắt plugin này là về giao diện cũ. Nên TẮT plugin "Giao diện VIP" khi dùng plugin này.
 * Version: 1.0.0
 * Author: iMaths Studio
 * Requires PHP: 7.4
 */
if (!defined('ABSPATH')) exit;

/* ---------- Vá lỗi: hosting không bật mbstring (giữ như bản VIP) ---------- */
if (!function_exists('mb_strtolower')) {
	function mb_strtolower($s, $enc = null) {
		$up = ['À','Á','Ả','Ã','Ạ','Ă','Ằ','Ắ','Ẳ','Ẵ','Ặ','Â','Ầ','Ấ','Ẩ','Ẫ','Ậ','Đ','È','É','Ẻ','Ẽ','Ẹ','Ê','Ề','Ế','Ể','Ễ','Ệ','Ì','Í','Ỉ','Ĩ','Ị','Ò','Ó','Ỏ','Õ','Ọ','Ô','Ồ','Ố','Ổ','Ỗ','Ộ','Ơ','Ờ','Ớ','Ở','Ỡ','Ợ','Ù','Ú','Ủ','Ũ','Ụ','Ư','Ừ','Ứ','Ử','Ữ','Ự','Ỳ','Ý','Ỷ','Ỹ','Ỵ'];
		$lo = ['à','á','ả','ã','ạ','ă','ằ','ắ','ẳ','ẵ','ặ','â','ầ','ấ','ẩ','ẫ','ậ','đ','è','é','ẻ','ẽ','ẹ','ê','ề','ế','ể','ễ','ệ','ì','í','ỉ','ĩ','ị','ò','ó','ỏ','õ','ọ','ô','ồ','ố','ổ','ỗ','ộ','ơ','ờ','ớ','ở','ỡ','ợ','ù','ú','ủ','ũ','ụ','ư','ừ','ứ','ử','ữ','ự','ỳ','ý','ỷ','ỹ','ỵ'];
		return strtolower(str_replace($up, $lo, (string) $s));
	}
}

/* ---------- API: ảnh đại diện (icon) + màu của từng game, đọc từ meta img:icon / img:accent ---------- */
add_action('rest_api_init', function () {
	register_rest_route('imaths-game/v1', '/gc-icons', ['methods' => 'GET', 'callback' => 'imggc_icons',
		'permission_callback' => function () { return is_user_logged_in(); }]);
});
function imggc_icons() {
	global $wpdb;
	if (!function_exists('img_t')) return (object) [];
	$t = img_t('games');
	$sig = (string) $wpdb->get_var("SELECT CONCAT(COUNT(*), '-', COALESCE(MAX(id),0), '-', COALESCE(SUM(LENGTH(slug)),0)) FROM $t");
	$key = 'imggc_ic_' . md5($sig);
	$c = get_transient($key);
	if (is_array($c)) return (object) $c;
	$rows = $wpdb->get_results("SELECT id, SUBSTRING(html, 1, 40000) h FROM $t", ARRAY_A);
	$out = [];
	foreach ((array) $rows as $r) {
		$ic = ''; $ac = '';
		if (preg_match('/<meta\s+name=["\']img:icon["\']\s+content=["\']([^"\']+)["\']/i', $r['h'], $m)) $ic = trim($m[1]);
		if ($ic && !preg_match('#^data:image/(svg\+xml|png|webp|jpeg);base64,[A-Za-z0-9+/=]+$#', $ic)) $ic = '';
		if (preg_match('/<meta\s+name=["\']img:accent["\']\s+content=["\'](#[0-9a-fA-F]{3,8})["\']/i', $r['h'], $m)) $ac = $m[1];
		$out[(int) $r['id']] = ['icon' => $ic, 'accent' => $ac];
	}
	set_transient($key, $out, 1800);
	return (object) $out;
}

/* ---------- Gắn giao diện vào shortcode (chạy cả ở chế độ app toàn màn hình) ---------- */
add_filter('do_shortcode_tag', function ($out, $tag) {
	if ($tag !== 'imaths_game_hub') return $out;
	$out .= '<style id="imggc-css">' . imggc_css() . '</style>';
	if (is_user_logged_in()) $out .= '<script id="imggc-js">' . imggc_js() . '</script>';
	return $out;
}, 20, 2);

function imggc_css() {
	return <<<'CSS'
/* ===== iMaths Games – Giao diện Game Center 1.0 ===== */
#img-hub,.img-modal,.img-toasts,#img-play{--bg:#f2f4fa;--card:#fff;--ink:#1c1d3b;--muted:#7a7f9a;--line:#e4e7f1;--coral:#ff5a5f;--mint:#22c08f;--sun:#ffb020;--grape:#7b61ff;--sky:#4f7dff;
 --gc-a1:#4f7dff;--gc-a2:#8b5cf6;--gc-soft:#eaf0ff;--gc-sh:0 2px 14px rgba(30,40,90,.07)}
body.img-app,body.img-app #img-hub{background:#f2f4fa!important}
#img-hub{background:var(--bg)!important;color:var(--ink);font-family:"Be Vietnam Pro",system-ui,sans-serif}
#img-hub.gc-ready{padding-bottom:calc(92px + env(safe-area-inset-bottom,0px))!important}
#img-hub.gc-ready .img-brand,#img-hub.gc-ready .img-tabs{display:none!important}

/* --- Thanh trên: ảnh đại diện · tên · cấp · đồng IMG --- */
#img-hub .img-top{display:flex!important;align-items:center;gap:10px!important;position:sticky;top:env(safe-area-inset-top,0px);z-index:20;
 background:rgba(255,255,255,.94)!important;-webkit-backdrop-filter:blur(10px);backdrop-filter:blur(10px);color:var(--ink)!important;
 border:0!important;border-radius:18px!important;box-shadow:var(--gc-sh)!important;padding:10px 12px!important;margin-bottom:14px}
#img-hub .img-top .img-ava{width:42px!important;height:42px!important;font-size:22px!important;border-radius:50%!important;border:0!important;
 background:linear-gradient(135deg,#e6ecff,#f1e8ff)!important;display:grid;place-items:center;flex:none;cursor:pointer;overflow:hidden}
#img-hub .img-top .who{flex:1;min-width:0}
#img-hub .img-top .nm{font-family:"Baloo 2",system-ui,sans-serif;font-weight:800;font-size:16px!important;line-height:1.2;color:var(--ink)!important;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
#img-hub .img-top .img-small{color:var(--muted)!important;font-size:11.5px!important;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
#img-hub .img-top .img-xpbar{height:5px!important;border:0!important;border-radius:9px;background:#eceffa!important;margin-top:4px;overflow:hidden}
#img-hub .img-top .img-xpbar i{display:block;height:100%;background:linear-gradient(90deg,var(--gc-a1),var(--gc-a2))!important}
#img-hub .img-top .img-chips{display:flex!important;gap:6px}
#img-hub .img-top .img-chip:not(.img-coinchip){display:none!important}
#img-hub .img-top .img-coinchip{background:linear-gradient(135deg,#ffcf4a,#ffa51f)!important;color:#4a2c00!important;border:0!important;border-radius:999px!important;
 padding:7px 12px!important;font-weight:800!important;font-size:13px!important;box-shadow:0 4px 12px rgba(255,165,31,.3);cursor:pointer;white-space:nowrap}

/* --- Thanh điều hướng dưới cùng --- */
.gc-nav{position:sticky;bottom:12px;z-index:30;margin-top:18px}
.gc-navin{display:grid;grid-auto-flow:column;grid-auto-columns:1fr;max-width:640px;margin:0 auto;background:#fff;border-radius:20px;box-shadow:0 6px 24px rgba(30,40,90,.12);padding:6px}
body.img-app .gc-nav{position:fixed;left:0;right:0;bottom:0;margin:0}
body.img-app .gc-navin{border-radius:0;box-shadow:0 -1px 0 var(--line),0 -6px 18px rgba(30,40,90,.05);max-width:none;
 padding:6px max(6px,env(safe-area-inset-right,0px)) calc(6px + env(safe-area-inset-bottom,0px)) max(6px,env(safe-area-inset-left,0px))}
@media (max-width:820px){
 .gc-nav{position:fixed;left:0;right:0;bottom:0;margin:0}
 .gc-navin{border-radius:0;box-shadow:0 -1px 0 var(--line),0 -6px 18px rgba(30,40,90,.05);max-width:none;
  padding:6px max(6px,env(safe-area-inset-right,0px)) calc(6px + env(safe-area-inset-bottom,0px)) max(6px,env(safe-area-inset-left,0px))}
}
#img-hub .gc-nb{position:relative;display:flex;flex-direction:column;align-items:center;gap:3px;border:0;background:none;padding:6px 2px;cursor:pointer;
 color:#9aa0b8;font:600 11px/1.1 "Be Vietnam Pro",system-ui,sans-serif;border-radius:14px;min-width:0}
#img-hub .gc-nb span{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:100%}
#img-hub .gc-nb svg{width:25px;height:25px;fill:none;stroke:currentColor;stroke-width:1.9;stroke-linecap:round;stroke-linejoin:round}
#img-hub .gc-nb.on{color:var(--gc-a1)}
#img-hub .gc-nb.on svg{fill:rgba(79,125,255,.14)}
#img-hub .gc-nb:focus-visible{outline:2px solid var(--gc-a1);outline-offset:-2px}
#img-hub .gc-dot{position:absolute;top:2px;left:calc(50% + 6px);min-width:17px;height:17px;padding:0 4px;border-radius:9px;background:var(--coral);color:#fff;
 font:700 10px/17px "Be Vietnam Pro",sans-serif;font-style:normal;text-align:center;border:2px solid #fff}

/* --- Màn Game Center --- */
#img-view.gc-on>:not(.gc){display:none!important}
.gc{display:flex;flex-direction:column;gap:16px}
.gc-pills{display:flex;gap:8px;overflow-x:auto;scrollbar-width:none;padding:2px 2px 6px;margin:0 -2px}
.gc-pills::-webkit-scrollbar{display:none}
#img-hub .gc-pill{flex:none;display:inline-flex;align-items:center;gap:7px;border:0;background:var(--gc-soft);color:var(--gc-a1);border-radius:999px;
 padding:9px 16px;font:600 14px/1 "Be Vietnam Pro",system-ui,sans-serif;cursor:pointer;transition:background .15s}
#img-hub .gc-pill svg{width:18px;height:18px;fill:none;stroke:currentColor;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}
#img-hub .gc-pill i{width:9px;height:9px;border-radius:50%;background:var(--c,#4f7dff);flex:none}
#img-hub .gc-pill.hot{color:#f04d52;background:#ffecee}
#img-hub .gc-pill.on{background:linear-gradient(135deg,var(--gc-a1),var(--gc-a2));color:#fff;box-shadow:0 6px 16px rgba(91,92,255,.28)}
#img-hub .gc-pill.on i{background:#fff}

/* Banner trượt */
.gc-ban{position:relative;border-radius:22px;overflow:hidden;box-shadow:0 10px 30px rgba(40,50,120,.18);isolation:isolate}
.gc-track{display:flex;overflow-x:auto;scroll-snap-type:x mandatory;scrollbar-width:none;scroll-behavior:smooth}
.gc-track::-webkit-scrollbar{display:none}
.gc-slide{flex:0 0 100%;scroll-snap-align:center;position:relative;height:clamp(196px,52vw,330px);overflow:hidden;cursor:pointer;color:#fff;
 background:radial-gradient(120% 90% at 85% 10%,rgba(255,255,255,.28),transparent 55%),linear-gradient(135deg,var(--c1),var(--c2));
 display:flex;flex-direction:column;justify-content:flex-end;padding:16px 16px 30px}
.gc-slide::after{content:"";position:absolute;inset:0;background:linear-gradient(0deg,rgba(14,14,44,.62),rgba(14,14,44,0) 62%);z-index:1}
.gc-glyph{position:absolute;font:800 64px/1 "Baloo 2",serif;color:rgba(255,255,255,.16);pointer-events:none;user-select:none}
.gc-sart{position:absolute;right:5%;top:9%;width:min(40%,210px);aspect-ratio:1;border-radius:28%;overflow:hidden;transform:rotate(8deg);
 box-shadow:0 18px 40px rgba(0,0,0,.28),0 0 0 4px rgba(255,255,255,.25);background:rgba(255,255,255,.18);display:grid;place-items:center;font-size:clamp(54px,14vw,96px);
 animation:gcBob 4s ease-in-out infinite}
.gc-sart img{width:100%;height:100%;object-fit:cover;display:block}
@keyframes gcBob{50%{transform:rotate(5deg) translateY(-6px)}}
.gc-stag{position:absolute;top:14px;left:14px;z-index:2;background:rgba(255,255,255,.92);color:var(--ink);font:800 11px/1 "Be Vietnam Pro",sans-serif;letter-spacing:.6px;
 padding:6px 10px;border-radius:999px}
.gc-stag.hot{background:#ff5a5f;color:#fff}
.gc-sinfo{position:relative;z-index:2;display:flex;align-items:center;gap:12px;min-width:0}
.gc-sico{width:54px;height:54px;border-radius:15px;flex:none;overflow:hidden;background:rgba(255,255,255,.22);border:2px solid rgba(255,255,255,.55);display:grid;place-items:center;font-size:28px}
.gc-sico img{width:100%;height:100%;object-fit:cover}
.gc-stx{flex:1;min-width:0}
.gc-stx b{display:block;font:800 21px/1.15 "Baloo 2",system-ui,sans-serif;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;text-shadow:0 2px 8px rgba(0,0,0,.25)}
.gc-stx span{display:block;font-size:13px;opacity:.9;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.gc-splay{flex:none;border:1px solid rgba(255,255,255,.55);background:rgba(255,255,255,.22);-webkit-backdrop-filter:blur(8px);backdrop-filter:blur(8px);color:#fff;
 border-radius:999px;padding:10px 18px;font:700 15px/1 "Be Vietnam Pro",sans-serif}
.gc-dots{position:absolute;left:0;right:0;bottom:11px;display:flex;justify-content:center;gap:6px;z-index:3;pointer-events:none}
.gc-dots i{width:14px;height:3px;border-radius:3px;background:rgba(255,255,255,.45);transition:width .25s,background .25s}
.gc-dots i.on{width:26px;background:#fff}

/* Khối danh sách */
.gc-sec{background:#fff;border-radius:20px;padding:14px 14px 16px;box-shadow:var(--gc-sh)}
.gc-sech{display:flex;align-items:center;justify-content:space-between;gap:10px;margin-bottom:12px}
.gc-sech h3{font:800 20px/1.2 "Baloo 2",system-ui,sans-serif!important;color:var(--ink)!important;margin:0!important;display:flex;align-items:center;gap:8px}
.gc-sech h3 small{font:600 12px "Be Vietnam Pro",sans-serif;color:var(--muted)}
#img-hub .gc-more{border:0;background:none;color:var(--muted);font:600 13.5px "Be Vietnam Pro",sans-serif;cursor:pointer;padding:4px 0;white-space:nowrap}
.gc-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:16px 10px}
@media (min-width:700px){.gc-grid{grid-template-columns:repeat(auto-fill,minmax(132px,1fr));gap:18px 14px}}
.gc-row{display:grid;grid-auto-flow:column;grid-auto-columns:calc((100% - 20px)/3.3);gap:10px;overflow-x:auto;scrollbar-width:none;scroll-snap-type:x mandatory}
.gc-row::-webkit-scrollbar{display:none}
.gc-row>.gc-tile{scroll-snap-align:start}
@media (min-width:700px){.gc-row{grid-auto-columns:132px;gap:14px}}
#img-hub .gc-tile{border:0;background:none;padding:0;text-align:left;cursor:pointer;display:flex;flex-direction:column;gap:7px;min-width:0;color:var(--ink);font:inherit}
.gc-th{position:relative;aspect-ratio:1;width:100%;border-radius:16px;overflow:hidden;display:grid;place-items:center;font-size:clamp(34px,10vw,52px);
 background:radial-gradient(90% 70% at 75% 15%,rgba(255,255,255,.35),transparent 60%),linear-gradient(135deg,var(--c1),var(--c2));transition:transform .15s}
.gc-th img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover}
#img-hub .gc-tile:hover .gc-th{transform:translateY(-2px)}
#img-hub .gc-tile:active .gc-th{transform:scale(.96)}
#img-hub .gc-tile:focus-visible .gc-th{outline:3px solid var(--gc-a1);outline-offset:2px}
.gc-rib{position:absolute;top:0;left:0;z-index:2;background:linear-gradient(135deg,#7b61ff,#a98bff);color:#fff;font:700 11.5px/1 "Be Vietnam Pro",sans-serif;
 padding:5px 10px 5px 9px;border-radius:16px 0 12px 0}
.gc-rib.hot{background:linear-gradient(135deg,#ff5a5f,#ff8a4c)}
.gc-rib.done{background:rgba(20,22,50,.6)}
.gc-tt{font-size:13px;font-weight:600;line-height:1.3;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}
.gc-mt{font-size:11.5px;color:var(--muted);margin-top:-3px;font-variant-numeric:tabular-nums}
.gc-empty{text-align:center;color:var(--muted);padding:26px 10px;font-size:14px}
.gc-sk{background:linear-gradient(90deg,#eceff7,#f6f7fb,#eceff7);background-size:200% 100%;animation:gcSk 1.2s linear infinite;border-radius:16px}
@keyframes gcSk{to{background-position:-200% 0}}

/* --- Làm mềm các màn khác cho hợp tông --- */
#img-hub .img-card,.img-modal .img-card{background:#fff!important;border:0!important;border-radius:18px!important;box-shadow:var(--gc-sh)!important}
.img-modal .img-card{box-shadow:0 20px 50px rgba(20,24,60,.25)!important}
.img-modal{background:rgba(20,22,50,.5)!important}
#img-hub .img-btn,.img-modal .img-btn{border:0!important;border-radius:999px!important;box-shadow:none!important;background:var(--gc-soft)!important;color:#3b5bdb!important;transform:none!important}
#img-hub .img-btn:hover,.img-modal .img-btn:hover{filter:brightness(.97)}
#img-hub .img-btn.coral,.img-modal .img-btn.coral{background:linear-gradient(135deg,var(--gc-a1),var(--gc-a2))!important;color:#fff!important}
#img-hub .img-btn.mint,.img-modal .img-btn.mint{background:var(--mint)!important;color:#fff!important}
#img-hub .img-btn.ghost,.img-modal .img-btn.ghost{background:#f1f3f9!important;color:var(--ink)!important}
#img-hub .img-input,.img-modal .img-input{border:1px solid var(--line)!important;border-radius:12px!important;background:#fff!important}
#img-hub .img-seg,.img-modal .img-seg{border:0!important;background:#e9ecf6!important;border-radius:999px!important;padding:3px}
#img-hub .img-seg button,.img-modal .img-seg button{border-radius:999px!important;color:var(--muted)}
#img-hub .img-seg button.on,.img-modal .img-seg button.on{background:#fff!important;color:var(--ink)!important;box-shadow:0 1px 4px rgba(30,40,90,.12)}
#img-hub .img-li{background:#fff!important;border:1px solid var(--line)!important;border-radius:14px!important}
#img-hub .img-li.me{background:#eef2ff!important;border-color:#c9d6ff!important}
#img-hub .img-li.top{border-color:#ffd98a!important}
#img-hub .img-tag,.img-modal .img-tag{border:0!important;background:#f1f3f9!important;border-radius:999px!important}
#img-hub .img-tag.new,.img-modal .img-tag.new{background:linear-gradient(135deg,#7b61ff,#a98bff)!important;color:#fff!important}
#img-hub .img-chip{border:1px solid var(--line)!important}
#img-hub .img-fchip,.img-modal .img-fchip{border:1px solid var(--line)!important}
#img-hub .img-fchip.on,.img-modal .img-fchip.on{background:var(--gc-a1)!important;border-color:var(--gc-a1)!important;color:#fff!important}
#img-hub .img-empty{border:1.5px dashed #d5d9e8!important}
#img-hub .img-stat div,#img-hub .img-bd,.img-modal .img-dslot{border:1px solid var(--line)!important;border-radius:14px!important}
#img-hub .img-avs button{border:1px solid var(--line)!important;border-radius:50%!important}
#img-hub .img-avs button.on{background:var(--gc-soft)!important;border-color:var(--gc-a1)!important}
#img-hub .img-install{border:0!important;background:#fff!important;box-shadow:var(--gc-sh)}
.img-toast{background:#1c1d3b!important;border-radius:999px!important}
@media (prefers-reduced-motion:reduce){.gc-sart{animation:none}.gc-track{scroll-behavior:auto}.gc-sk{animation:none}}
CSS;
}

function imggc_js() {
	return <<<'JS'
(function(){
const C = window.IMG_CFG, root = document.getElementById('img-hub');
if (!C || !root) return;

const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const url = p => { let u = C.rest + p; if (C.rest.indexOf('?') >= 0) u = C.rest + p.replace('?', '&'); return u; };
const get = p => fetch(url(p), { credentials: 'same-origin', headers: { 'X-WP-Nonce': C.nonce } }).then(r => r.ok ? r.json() : null).catch(() => null);
const SV = (d, cls) => '<svg viewBox="0 0 24 24" aria-hidden="true"' + (cls ? ' class="' + cls + '"' : '') + '>' + d + '</svg>';

/* Màu theo kệ chủ đề */
const TH = {
	'Phiêu lưu & Khám phá': ['#3aa6ff', '#5b5bff', 'Phiêu lưu'],
	'Chiến thuật & Phòng thủ': ['#22c08f', '#0f8b86', 'Chiến thuật'],
	'Hành động & Tốc độ': ['#ff7a3d', '#ff3d71', 'Hành động'],
	'Trinh thám & Giải đố': ['#9b6bff', '#5b3fd6', 'Giải đố'],
	'Mô phỏng & Xây dựng': ['#fbbf24', '#f97316', 'Xây dựng'],
	'Thể thao & Âm nhạc': ['#ff5d9e', '#c43ad6', 'Thể thao']
};
const thOf = g => TH[g.theme] || TH['Phiêu lưu & Khám phá'];
const EMO = [[/rồng|dragon/i,'🐲'],[/vũ trụ|space|tên lửa|thiên hà|hành tinh/i,'🚀'],[/đua|race|xe/i,'🏎️'],[/thủ thành|tower|phòng thủ/i,'🏰'],
	[/cướp biển|kho báu|pirate/i,'🏴‍☠️'],[/zombie|xác sống/i,'🧟'],[/bóng|penalty/i,'⚽'],[/mê cung|maze/i,'🌀'],[/nấu|bếp|cook/i,'🍜'],
	[/nông trại|farm/i,'🌾'],[/câu cá|đại dương|biển/i,'🐠'],[/nhạc|rhythm|nhịp/i,'🎵'],[/thám tử|trinh thám|phá án|escape|thoát/i,'🕵️'],
	[/boss|rpg|chiến binh|đấu|nhập vai/i,'⚔️'],[/xếp hình|puzzle|ghép|đố/i,'🧩'],[/thành phố|city|xây/i,'🏙️'],[/bắn cung|cung thủ/i,'🏹'],
	[/sinh tồn|đảo/i,'🏝️'],[/bắn|shooter/i,'🎯'],[/phản xạ|tốc độ|nhanh/i,'⚡']];
const emo = g => { const s = (g.genre || '') + ' ' + (g.title || ''); for (const a of EMO) if (a[0].test(s)) return a[1]; return '🎮'; };
const ts = d => { const t = new Date(String(d || '').replace(' ', 'T')).getTime(); return isNaN(t) ? 0 : t; };
const DAY = 864e5;

const IC = {
	play: '<rect x="2" y="6" width="20" height="12" rx="6"/><path d="M6.5 12h4M8.5 10v4"/><circle cx="15.5" cy="11" r=".6"/><circle cx="17.8" cy="13.2" r=".6"/>',
	coins: '<circle cx="12" cy="12" r="9"/><path d="M14.6 9.4c-.5-.9-1.5-1.4-2.6-1.4-1.4 0-2.5.8-2.5 2s1.1 1.6 2.5 1.9 2.5.8 2.5 2-1.1 2.1-2.5 2.1c-1.1 0-2.1-.5-2.6-1.4M12 6.4V8M12 16v1.6"/>',
	board: '<path d="M8 21h8M12 17v4M7 4h10v5a5 5 0 0 1-10 0V4zM17 5h3v2a3 3 0 0 1-3 3M7 5H4v2a3 3 0 0 0 3 3"/>',
	friends: '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c.6-3.5 3.3-5.5 6.5-5.5s5.9 2 6.5 5.5M16 4.8a3.5 3.5 0 0 1 0 6.4M18 14.8c1.9.8 3.1 2.6 3.5 5.2"/>',
	duel: '<path d="M14.5 17.5 3 6V3h3l11.5 11.5M13 19l6-6M16 16l4 4M19 21l2-2M9.5 6.5 14 2h3v3l-4.5 4.5M5 14l-2 2 4 4 2-2"/>',
	me: '<circle cx="12" cy="8" r="4"/><path d="M4 21c.8-4 4-6 8-6s7.2 2 8 6"/>',
	admin: '<path d="M4 6h10M18 6h2M4 12h4M12 12h8M4 18h12"/><circle cx="16" cy="6" r="2"/><circle cx="10" cy="12" r="2"/><circle cx="18" cy="18" r="2"/>'
};
const NAVL = { play: 'Game', coins: 'IMG', board: 'Xếp hạng', friends: 'Bạn bè', duel: 'Thách đố', me: 'Tôi', admin: 'Quản lý' };
const PI = {
	all: '<rect x="3" y="3" width="7" height="7" rx="2"/><rect x="14" y="3" width="7" height="7" rx="2"/><rect x="3" y="14" width="7" height="7" rx="2"/><rect x="14" y="14" width="7" height="7" rx="2"/>',
	cont: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
	new: '<path d="M5 15c-1.5 1.5-2 4-2 6 2 0 4.5-.5 6-2"/><path d="M9 18l-3-3c1-4 4-9.5 12-12 0 0 .5 0 .5.5C16 11 11 14 9 18z"/><circle cx="14.5" cy="9.5" r="1.4"/>',
	hot: '<path d="M12 3c1 3 5 5 5 10a5 5 0 0 1-10 0c0-2 1-3.5 2-4.5 0 2 1 3 2 3 0-3-1-5 1-8.5z"/>'
};

/* ---------- Dữ liệu ---------- */
let GAMES = null, ICONS = {}, gotAt = 0, F = 'all', timer = 0;
async function data() {
	if (GAMES && Date.now() - gotAt < 60000) return GAMES;
	const [g, ic] = await Promise.all([get('/games'), get('/gc-icons')]);
	if (Array.isArray(g)) GAMES = g;
	if (ic && typeof ic === 'object') ICONS = ic;
	gotAt = Date.now();
	return GAMES || [];
}
const icon = g => { const i = ICONS[g.id]; return i && i.icon ? i.icon : ''; };
const cols = g => { const t = thOf(g), a = ICONS[g.id] && ICONS[g.id].accent; return [a || t[0], t[1]]; };

/* ---------- Ô game ---------- */
function tile(g, now) {
	const [c1, c2] = cols(g), src = icon(g), age = now - ts(g.created_at);
	const rib = age < 3 * DAY ? '<span class="gc-rib">Mới</span>' : (g.hot ? '<span class="gc-rib hot">Hot</span>' : '');
	const mt = g.best != null ? 'Kỷ lục ' + g.best : (g.plays ? g.plays + ' lượt chơi' : 'Chưa ai chơi');
	return `<button type="button" class="gc-tile" data-play="${g.id}" aria-label="Chơi ${esc(g.title)}">
		<span class="gc-th" style="--c1:${c1};--c2:${c2}">${src ? `<img src="${esc(src)}" alt="" loading="lazy">` : emo(g)}${rib}</span>
		<span class="gc-tt">${esc(g.title)}</span><span class="gc-mt">${esc(mt)}</span></button>`;
}
function section(title, sub, list, now, more, row) {
	if (!list.length) return '';
	return `<section class="gc-sec"><div class="gc-sech"><h3>${title}${sub ? ` <small>${sub}</small>` : ''}</h3>${more ? `<button type="button" class="gc-more" data-gcf="${esc(more)}">Xem hết ›</button>` : ''}</div>
		<div class="${row ? 'gc-row' : 'gc-grid'}">${list.map(g => tile(g, now)).join('')}</div></section>`;
}
const GLY = ['∑', 'π', '√', '∫', '÷', '∞', 'x²', '△'];
function slide(g, tag, k) {
	const [c1, c2] = cols(g), src = icon(g), e = emo(g);
	const gl = [0, 1, 2].map(i => { const ch = GLY[(g.id + i * 3 + k) % GLY.length], pos = [['8%', '14%'], ['44%', '6%'], ['30%', '48%']][i];
		return `<span class="gc-glyph" style="left:${pos[0]};top:${pos[1]};font-size:${[70, 46, 58][i]}px">${ch}</span>`; }).join('');
	return `<div class="gc-slide" data-play="${g.id}" style="--c1:${c1};--c2:${c2}" role="button" tabindex="0" aria-label="Chơi ${esc(g.title)}">${gl}
		<span class="gc-sart">${src ? `<img src="${esc(src)}" alt="">` : e}</span>
		<span class="gc-stag ${tag[1]}">${tag[0]}</span>
		<div class="gc-sinfo"><span class="gc-sico">${src ? `<img src="${esc(src)}" alt="">` : e}</span>
		<span class="gc-stx"><b>${esc(g.title)}</b><span>${esc(g.descr || g.genre || '')}</span></span><span class="gc-splay">Chơi</span></div></div>`;
}

/* ---------- Vẽ màn Game Center ---------- */
async function mount(v) {
	v.classList.add('gc-on');
	const box = document.createElement('div'); box.className = 'gc';
	box.innerHTML = '<div class="gc-sk" style="height:38px;border-radius:999px;width:70%"></div><div class="gc-sk" style="height:220px;border-radius:22px"></div><div class="gc-sk" style="height:260px"></div>';
	v.appendChild(box);
	box.addEventListener('click', e => { const f = e.target.closest('[data-gcf]'); if (f) { F = f.dataset.gcf; paint(box); window.scrollTo({ top: 0, behavior: 'smooth' }); } });
	box.addEventListener('keydown', e => { if ((e.key === 'Enter' || e.key === ' ') && e.target.classList.contains('gc-slide')) { e.preventDefault(); e.target.click(); } });
	await data();
	if (!box.isConnected) return;
	if (!GAMES || !GAMES.length) { v.classList.remove('gc-on'); box.remove(); return; }
	paint(box);
}
function paint(box) {
	const now = Date.now(), all = GAMES.slice();
	const hotList = all.slice().sort((a, b) => b.plays - a.plays);
	const hotIds = new Set(hotList.filter(g => g.plays > 0).slice(0, 6).map(g => g.id));
	all.forEach(g => { g.hot = hotIds.has(g.id); });
	const cont = all.filter(g => g.best != null);
	const fresh = all.filter(g => now - ts(g.created_at) < 14 * DAY);
	const newList = fresh.length >= 3 ? fresh : all.slice(0, 9);
	const themes = Object.keys(TH).filter(t => all.some(g => g.theme === t));
	if (F !== 'all' && F !== 'cont' && F !== 'new' && F !== 'hot' && themes.indexOf(F) < 0) F = 'all';
	if (F === 'cont' && !cont.length) F = 'all';

	const pill = (k, label, ic, extra) => `<button type="button" class="gc-pill ${extra || ''} ${F === k ? 'on' : ''}" data-gcf="${esc(k)}">${ic}${label}</button>`;
	let h = '<div class="gc-pills" role="tablist">' + pill('all', 'Tất cả', SV(PI.all))
		+ (cont.length ? pill('cont', 'Chơi tiếp', SV(PI.cont)) : '') + pill('new', 'Game mới', SV(PI.new)) + pill('hot', 'Hot', SV(PI.hot), 'hot')
		+ themes.map(t => pill(t, esc(TH[t][2]), `<i style="--c:${TH[t][0]}"></i>`)).join('') + '</div>';

	if (F === 'all') {
		const today = all[0], isNew = now - ts(today.created_at) < 30 * 36e5;
		const slides = [[today, [isNew ? 'MỚI HÔM NAY' : 'GAME MỚI NHẤT', '']]].concat(hotList.filter(g => g.id !== today.id && g.plays > 0).slice(0, 4).map(g => [g, ['HOT', 'hot']]));
		h += `<div class="gc-ban"><div class="gc-track">${slides.map((s, k) => slide(s[0], s[1], k)).join('')}</div>
			${slides.length > 1 ? `<div class="gc-dots">${slides.map((s, k) => `<i class="${k ? '' : 'on'}"></i>`).join('')}</div>` : ''}</div>`;
		h += section('Chơi tiếp', '', cont.slice(0, 12), now, cont.length > 12 ? 'cont' : '', true);
		h += section('Game mới', '', newList.slice(0, 6), now, newList.length > 6 ? 'new' : '');
		if (all.length > 6) h += section('Hot nhất', '', hotList.slice(0, 6), now, 'hot');
		themes.forEach(t => { const l = all.filter(g => g.theme === t); h += section(esc(t), l.length + ' game', l.slice(0, 6), now, l.length > 6 ? t : ''); });
	} else {
		const L = F === 'cont' ? cont : F === 'new' ? newList : F === 'hot' ? hotList : all.filter(g => g.theme === F);
		const name = F === 'cont' ? 'Chơi tiếp' : F === 'new' ? 'Game mới' : F === 'hot' ? 'Hot nhất' : esc(F);
		h += L.length ? section(name, L.length + ' game', L, now, '') : '<div class="gc-sec gc-empty">Chưa có game nào ở mục này.</div>';
	}
	box.innerHTML = h;
	const on = box.querySelector('.gc-pill.on'); if (on && on.scrollIntoView) on.scrollIntoView({ block: 'nearest', inline: 'center' });
	carousel(box);
}
function carousel(box) {
	clearInterval(timer);
	const tr = box.querySelector('.gc-track'), dots = box.querySelectorAll('.gc-dots i'); if (!tr || dots.length < 2) return;
	const idx = () => Math.round(tr.scrollLeft / Math.max(1, tr.clientWidth));
	tr.addEventListener('scroll', () => { const i = idx(); dots.forEach((d, k) => d.classList.toggle('on', k === i)); }, { passive: true });
	let hold = 0; const pause = () => { hold = Date.now(); };
	tr.addEventListener('pointerdown', pause); tr.addEventListener('touchstart', pause, { passive: true });
	if (window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches) return;
	timer = setInterval(() => {
		if (!tr.isConnected) { clearInterval(timer); return; }
		if (Date.now() - hold < 7000 || document.hidden || document.getElementById('img-play') && !document.getElementById('img-play').hidden) return;
		const n = (idx() + 1) % dots.length; tr.scrollTo({ left: n * tr.clientWidth, behavior: 'smooth' });
	}, 4500);
}

/* ---------- Thanh điều hướng dưới ---------- */
function nav() {
	const tabs = [...root.querySelectorAll('.img-tabs .img-tab')]; if (!tabs.length) return;
	const old = root.querySelector('.gc-nav'); if (old) old.remove();
	const n = document.createElement('nav'); n.className = 'gc-nav'; n.setAttribute('aria-label', 'Điều hướng');
	n.innerHTML = '<div class="gc-navin">' + tabs.map(t => { const k = t.dataset.tab, b = t.querySelector('.img-badge');
		return `<button type="button" class="gc-nb ${t.classList.contains('on') ? 'on' : ''}" data-tab="${esc(k)}" ${t.classList.contains('on') ? 'aria-current="page"' : ''}>${SV(IC[k] || IC.play)}<span>${NAVL[k] || esc(t.textContent)}</span>${b ? `<i class="gc-dot">${esc(b.textContent)}</i>` : ''}</button>`; }).join('') + '</div>';
	root.appendChild(n);
	root.classList.add('gc-ready');
}

/* ---------- Theo dõi sân chơi vẽ lại ---------- */
function apply() {
	if (root.querySelector('.img-tabs') && !root.querySelector('.gc-nav')) nav();
	const v = root.querySelector('#img-view'); if (!v || v.querySelector('.gc')) return;
	const onPlay = !!root.querySelector('.img-tabs .img-tab.on[data-tab="play"]');
	if (onPlay && v.querySelector('.img-today')) mount(v);
}
let raf = 0;
new MutationObserver(() => { if (!raf) raf = requestAnimationFrame(() => { raf = 0; apply(); }); }).observe(root, { childList: true, subtree: true });
apply();
})();
JS;
}
