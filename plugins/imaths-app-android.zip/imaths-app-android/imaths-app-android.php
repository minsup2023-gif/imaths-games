<?php
/**
 * Plugin Name: iMaths Games – App Android
 * Description: Chuẩn bị website để đóng gói iMaths Games thành app Android (PWABuilder / Trusted Web Activity): tự phục vụ file /.well-known/assetlinks.json (gắn app với website, app mở toàn màn hình không hiện thanh địa chỉ) và một service worker nhẹ (trang báo mất mạng). Cài đặt: Cài đặt → iMaths App Android.
 * Version: 1.0.0
 * Author: iMaths Studio
 * Requires PHP: 7.4
 */
if (!defined('ABSPATH')) exit;

/* ---------- Cài đặt ---------- */
function imgapp_pkg() {
	$p = trim((string) get_option('imgapp_package', ''));
	return preg_match('/^[a-zA-Z][\w]*(\.[a-zA-Z][\w]*)+$/', $p) ? $p : 'com.imaths.games';
}
function imgapp_fingerprints() {
	$raw = strtoupper((string) get_option('imgapp_sha256', ''));
	preg_match_all('/(?:[0-9A-F]{2}:){31}[0-9A-F]{2}/', $raw, $m);
	return array_values(array_unique($m[0]));
}

add_action('admin_menu', function () {
	add_options_page('iMaths App Android', 'iMaths App Android', 'manage_options', 'imgapp', 'imgapp_settings_page');
});
add_action('admin_init', function () {
	register_setting('imgapp', 'imgapp_package', ['type' => 'string', 'sanitize_callback' => 'sanitize_text_field']);
	register_setting('imgapp', 'imgapp_sha256', ['type' => 'string', 'sanitize_callback' => 'sanitize_textarea_field']);
});

function imgapp_settings_page() {
	$al = home_url('/.well-known/assetlinks.json');
	$fps = imgapp_fingerprints();
	$sub = trim((string) wp_parse_url(home_url('/'), PHP_URL_PATH), '/'); ?>
	<div class="wrap">
		<h1>iMaths App Android</h1>
		<p>Dùng khi đóng gói iMaths Games thành app Android bằng <b>pwabuilder.com</b>. Làm theo tài liệu "Tạo app Android iMaths Games".</p>
		<?php if ($sub !== '') echo '<div class="notice notice-warning"><p>WordPress đang nằm trong thư mục con <code>/' . esc_html($sub) . '</code>. Android chỉ đọc file ở gốc tên miền, nên bạn phải tự tải <code>assetlinks.json</code> vào <code>public_html/.well-known/</code>.</p></div>'; ?>
		<form method="post" action="options.php">
			<?php settings_fields('imgapp'); ?>
			<table class="form-table">
				<tr><th>Package ID</th><td><input name="imgapp_package" class="regular-text" value="<?php echo esc_attr(imgapp_pkg()); ?>">
					<p class="description">Phải giống hệt ô "Package ID" đã điền trên PWABuilder.</p></td></tr>
				<tr><th>Mã SHA-256 của khoá ký</th><td><textarea name="imgapp_sha256" rows="5" class="large-text code" placeholder="AB:CD:12:…  (mỗi mã một dòng)"><?php echo esc_textarea(get_option('imgapp_sha256', '')); ?></textarea>
					<p class="description">Dán từ file <code>assetlinks.json</code> trong gói PWABuilder (dòng sha256_cert_fingerprints). Lên Google Play thì dán thêm mã "App signing key" trong Play Console. Có thể dán cả file, plugin tự lọc lấy mã.</p></td></tr>
			</table>
			<?php submit_button('Lưu'); ?>
		</form>
		<h2>Kiểm tra</h2>
		<p>Đã nhận <b><?php echo count($fps); ?></b> mã SHA-256. Mở thử: <a href="<?php echo esc_url($al); ?>" target="_blank"><?php echo esc_html($al); ?></a> – phải thấy chữ <code><?php echo esc_html(imgapp_pkg()); ?></code>.</p>
	</div>
<?php }

/* ---------- Phục vụ /.well-known/assetlinks.json và service worker ---------- */
add_action('init', function () {
	$path = (string) wp_parse_url(isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '', PHP_URL_PATH);
	if (preg_match('#/\.well-known/assetlinks\.json$#', $path)) {
		$out = [];
		$fps = imgapp_fingerprints();
		if ($fps) $out[] = ['relation' => ['delegate_permission/common.handle_all_urls'],
			'target' => ['namespace' => 'android_app', 'package_name' => imgapp_pkg(), 'sha256_cert_fingerprints' => $fps]];
		status_header(200);
		header('Content-Type: application/json; charset=utf-8');
		header('Access-Control-Allow-Origin: *');
		header('Cache-Control: public, max-age=3600');
		echo wp_json_encode($out, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
		exit;
	}
	if (isset($_GET['img_sw'])) {
		status_header(200);
		header('Content-Type: application/javascript; charset=utf-8');
		header('Service-Worker-Allowed: /');
		header('Cache-Control: no-cache');
		echo imgapp_sw_js();
		exit;
	}
}, 0);

function imgapp_sw_js() {
	return <<<'JS'
/* iMaths Games – service worker: luôn lấy bản mới từ mạng; mất mạng thì hiện trang báo */
const OFF = `<!doctype html><html lang="vi"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>iMaths Games</title><body style="margin:0;min-height:100vh;display:grid;place-items:center;background:#f2f4fa;font-family:system-ui,sans-serif;color:#1c1d3b;text-align:center;padding:24px">
<div><div style="font-size:56px">📡</div><h2 style="margin:8px 0">Mất kết nối mạng</h2><p style="color:#7a7f9a">Bật Wi-Fi hoặc 4G rồi thử lại nhé.</p>
<button onclick="location.reload()" style="margin-top:12px;border:0;border-radius:999px;padding:12px 22px;font-size:16px;font-weight:700;color:#fff;background:linear-gradient(135deg,#4f7dff,#8b5cf6)">Thử lại</button></div></body></html>`;
self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', e => e.waitUntil(self.clients.claim()));
self.addEventListener('fetch', e => {
	if (e.request.mode !== 'navigate') return;
	e.respondWith(fetch(e.request).catch(() => new Response(OFF, { headers: { 'Content-Type': 'text/html; charset=utf-8' } })));
});
JS;
}

/* ---------- Đăng ký service worker trên trang iMaths Games ---------- */
add_filter('do_shortcode_tag', function ($out, $tag) {
	if ($tag !== 'imaths_game_hub') return $out;
	// Website đã có plugin PWA riêng (SuperPWA…) thì để service worker của plugin đó, tránh hai bản giành nhau
	if (defined('SUPERPWA_VERSION') || function_exists('superpwa_sw')) return $out;
	$sw = esc_url_raw(add_query_arg('img_sw', '1', home_url('/')));
	return $out . '<script>if("serviceWorker" in navigator)window.addEventListener("load",function(){navigator.serviceWorker.register(' . wp_json_encode($sw) . ',{scope:"/"}).catch(function(){});});</script>';
}, 30, 2);
